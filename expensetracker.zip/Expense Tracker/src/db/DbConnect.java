package db;
import java.sql.*;

public class DbConnect {
	private Connection con;
    private Statement st;
    private PreparedStatement statusCheck,checkUser,insertUser,deleteUser,changePass;
    public DbConnect(){
     try{
    	 Class.forName(�oracle.jdbc.driver.OracleDriver�);
 Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",expensetracker,expensetracker);
 st=con.createStatement();
  statusCheck=con.prepareStatement("select status from user_info where username=?");
 checkUser=con.prepareStatement("select * from user_info where username=? and psw=?");
 insertUser=con.prepareStatement(
		 "insert into user_info (name,phn,adrs,grp-name,dob,username,psw,psw-repeat,status) values (?,?,?,?,?,?,?,?,?'Active')");
deleteUser=con.prepareStatement("update user_info set status='Deactivate' where username=?");
changePass=con.prepareStatement(
		 "update user_info set psw=? where username=? and psw=?");
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    public ResultSet getUser(String uname,String ps){
        try{
 checkUser.setString(1, uname);
 checkUser.setString(2, ps);
 ResultSet rs=checkUser.executeQuery();
 return rs;
        }catch(Exception ex){
            ex.printStackTrace();
            return null;
        }
    }
    public String statusCheck(String uname){
        try{
        	statusCheck.setString(1, uname);
        	ResultSet rs=statusCheck.executeQuery();
        	if(rs.next()){
        		return rs.getString(1);
        	}else{
        		return "Username Not Found";
        	}
        	
        }catch(Exception ex){
            ex.printStackTrace();
            return ex.getMessage();
        }
    }
    public boolean deleteUser(String uname){
        try{
        	deleteUser.setString(1, uname);
        	deleteUser.executeUpdate();
        	return true;
        }catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
    }
    public boolean changePass(String np,String uname,String op){
        try{
        	changePass.setString(1, np);
        	changePass.setString(2, uname);
        	changePass.setString(3, op);
        	int x=changePass.executeUpdate();
        	if(x!=0)
        		return true;
        	else 
        		return false;
        }catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
    }
    public String setUser(String n,String n,String ph,int a,String p){
        try{
 insertUser.setString(1, n);
 insertUser.setString(2, ph);
 insertUser.setString(3, adr);
 insertUser.setString(4, grpn);
 insertUser.setInt(5, dt);
 insertUser.setString(6, uname);
 insertUser.setString(7, ps);
 insertUser.setString(8, rps);
int x=insertUser.executeUpdate();
if(x==1)
 return "Done";
else 
 return "Registration Failed";
        }
        catch(java.sql.SQLIntegrityConstraintViolationException ex){
            ex.printStackTrace();
            return "Email Id already Exist";
        }
        catch(Exception ex){
            ex.printStackTrace();
            return "Registration Failed: "+ex.getMessage();
        }
    }
}
